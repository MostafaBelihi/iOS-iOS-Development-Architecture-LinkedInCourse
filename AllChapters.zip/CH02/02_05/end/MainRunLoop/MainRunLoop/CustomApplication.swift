//
//  CustomApplication.swift
//  MainRunLoop
//
//  Created by Karoly Nyisztor on 6/5/18.
//  Copyright © 2018 Karoly Nyisztor. All rights reserved.
//

import UIKit

class CustomApplication: UIApplication {
    override func sendEvent(_ event: UIEvent) {
        print("Intercepted event \(event)")
        super.sendEvent(event)
    }
}
