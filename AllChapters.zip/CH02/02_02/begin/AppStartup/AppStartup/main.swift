//
//  main.swift
//  AppStartup
//
//  Created by Karoly Nyisztor on 6/5/18.
//  Copyright © 2018 Karoly Nyisztor. All rights reserved.
//

import UIKit

UIApplicationMain(CommandLine.argc, UnsafeMutableRawPointer(CommandLine.unsafeArgv).bindMemory(to: UnsafeMutablePointer<Int8>.self, capacity: Int(CommandLine.argc)), nil, NSStringFromClass(AppDelegate.self)
)
