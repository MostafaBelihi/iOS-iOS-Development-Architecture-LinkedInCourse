//
//  ViewController.swift
//  AppStartup
//
//  Created by Karoly Nyisztor on 6/5/18.
//  Copyright © 2018 Karoly Nyisztor. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textView: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func encodeRestorableState(with coder: NSCoder) {
        super.encodeRestorableState(with: coder)
        
        if textView.isFirstResponder {
            coder.encode(textView.text, forKey: "EditedText")
        }
    }
    
    

}












